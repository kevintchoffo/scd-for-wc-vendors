<?php
/*
  Plugin Name: SCD - Smart Currency Detector - Premium Variant for WcVendor
  Plugin URI: http://gajelabs.com/
  Description: This wordpress / woocommerce plugin is an ALL-IN-ONE solution for online market places owners, sellers, end customers. Multivendors variant
  Version: 4.8.0.0
  WC tested up to: 5.9

  Author: GaJeLabs
  Author URI: http://gajelabs.com
 */
 

if (in_array('scd-smart-currency-detector/index.php', apply_filters('active_plugins', get_option('active_plugins')))){ 
    include 'scd_multivendors_renders.php';
    require 'scd_wcv_multivendor.php';
    //include 'includes/index.php';
}


define( 'SCDS_PLUGIN_DIR_PATH', plugin_dir_path( __FILE__ ) );


add_action('init', function () {
    if ( is_admin() && in_array('scd-smart-currency-detector-variant-for-wcv/index.php', apply_filters('active_plugins', get_option('active_plugins'))) ) {
        $current_page = filter_input(INPUT_GET, 'page');
     //   require_once 'scd_free_install.php';
     }
	
});

function scd_multi_add_scrypt_topost() {
     wp_enqueue_script("scd-wcv-multivendor", trailingslashit(plugins_url("", __FILE__)) . "js/scd_wcv_multivendor.js", array("jquery"));
    $variable_to_js = [
		'ajax_url' => admin_url('admin-ajax.php')
	];
	wp_localize_script('scd-wcv-multivendor', 'scd_ajax', $variable_to_js);

}
add_action('wp_enqueue_scripts', 'scd_multi_add_scrypt_topost');

function scd_get_slm_info(){
    return json_decode(file_get_contents(SCDS_PLUGIN_DIR_PATH . "slm.json"));
}

add_action('admin_notices','scd_premium_require');
function scd_premium_require() {
if(!is_plugin_active('scd-smart-currency-detector/index.php')){
    echo '<h3 style="color:red;">SCD Multivendors for Wc vendors require scd-smart-currency-detector before use, please <a target="__blank" href="https://wordpress.org/plugins/scd-smart-currency-detector/"> download and install it here</a><h3>';    
}
}

